console.log("album_upload.js BETÖLTÖDÖTT! – most már futok");

// URL regex minták – csak Spotify/Apple Music előadói profil linkek elfogadása
const spotifyRegex = /^https:\/\/open\.spotify\.com\/artist\/[a-zA-Z0-9]+(\?.*)?$/;
const appleRegex  = /^https:\/\/music\.apple\.com\/[a-z]{2}\/artist\/.+\/[0-9]+(\?.*)?$/;

document.addEventListener('DOMContentLoaded', () => {
  console.log("DOMContentLoaded fut – gombok bekötése indul");

  const coverBox    = document.getElementById("coverBox");
  const coverInput  = document.getElementById("coverInput");
  const errorText   = document.getElementById("errorText");
  const previewImage = document.getElementById("previewImage");
  const artistInput = document.getElementById("artistInput");
  const titleInput  = document.getElementById("titleInput");

  // --- Borító feltöltés ---
  coverBox.addEventListener("click", () => {
    coverInput.click();
  });

  coverInput.addEventListener("change", () => {
    const file = coverInput.files[0];
    errorText.textContent = "";
    previewImage.src = "";
    previewImage.style.display = "none";

    if (!file || !file.type.startsWith("image/")) {
      errorText.textContent = "Csak képfájl tölthető fel!";
      return;
    }

    const reader = new FileReader();
    reader.onload = function(e) {
      const img = new Image();
      img.src = e.target.result;
      img.onload = () => {
        if (img.width < 1500 || img.height < 1500) {
          errorText.textContent = "A borító legalább 1500x1500 pixel kell legyen!";
          return;
        }
        previewImage.src = img.src;
        previewImage.style.display = "block";
        localStorage.setItem("tempAlbumCover", e.target.result);
      };
    };
    reader.readAsDataURL(file);
  });

  // --- Átmeneti mentés ---
  if (artistInput) {
    artistInput.addEventListener("input", e => {
      localStorage.setItem("tempAlbumArtist", e.target.value);
    });
  }
  if (titleInput) {
    titleInput.addEventListener("input", e => {
      localStorage.setItem("tempAlbumTitle", e.target.value);
    });
  }

  // --- TRACK gomb ---
  const trackBtn = document.getElementById("trackUploadBtn");
  if (trackBtn) {
    trackBtn.addEventListener('click', (e) => {
      e.preventDefault();
      console.log("TRACK gomb kattintás – validáció indul");

      const isValid = validateForm();
      if (isValid) {
        console.log("Minden OK – átirányítás track_upload.html-re");
        errorText.textContent = '';
        window.location.href = 'track_upload.html';
      } else {
        console.log("Hiba – nem megy át");
      }
    });
  }

  // --- Validáció ---
  function validateForm() {
    let isValid = true;
    let errors = [];
    errorText.textContent = '';

    // Stílusok visszaállítása
    document.querySelectorAll('input, select').forEach(el => el.style.borderColor = '');
    coverBox.style.borderColor = '';

    // 1) Albumkód igénylés – kötelező választás
    const albumCodeSelect = document.getElementById("albumCodeRequest");
    if (!albumCodeSelect.value) {
      isValid = false;
      albumCodeSelect.style.borderColor = '#ff3366';
    }

    // 2) EAN/UPC – csak akkor kötelező, ha albumkód igénylés NEM "igen"
    const eanInput = document.getElementById("eanInput");
    if (albumCodeSelect.value !== 'igen' && eanInput.value.trim() === '') {
      isValid = false;
      eanInput.style.borderColor = '#ff3366';
    }

    // 3) Kötelező szöveges mezők
    const requiredTextIds = ['artistInput', 'titleInput'];
    requiredTextIds.forEach(id => {
      const field = document.getElementById(id);
      if (!field) return;
      if (field.value.trim() === '') {
        isValid = false;
        field.style.borderColor = '#ff3366';
      }
    });

    // 4) Kötelező legördülő menük (Stílus, Továbbterjesztés)
    const requiredSelectIds = ['genreSelect', 'distributionSelect'];
    requiredSelectIds.forEach(id => {
      const field = document.getElementById(id);
      if (!field) return;
      if (!field.value) {
        isValid = false;
        field.style.borderColor = '#ff3366';
      }
    });

    // 5) Spotify URL – kötelező + csak Spotify előadói profil link
    const spotifyUrlField = document.getElementById('spotifyUrl');
    if (!spotifyUrlField.value.trim()) {
      isValid = false;
      spotifyUrlField.style.borderColor = '#ff3366';
    } else if (!spotifyRegex.test(spotifyUrlField.value.trim())) {
      isValid = false;
      spotifyUrlField.style.borderColor = '#ff3366';
      errors.push('Spotify URL: csak előadói profil link elfogadott (https://open.spotify.com/artist/...)');
    }

    // 6) Apple Music URL – kötelező + csak Apple Music előadói profil link
    const appleUrlField = document.getElementById('appleMusicUrl');
    if (!appleUrlField.value.trim()) {
      isValid = false;
      appleUrlField.style.borderColor = '#ff3366';
    } else if (!appleRegex.test(appleUrlField.value.trim())) {
      isValid = false;
      appleUrlField.style.borderColor = '#ff3366';
      errors.push('Apple Music URL: csak előadói profil link elfogadott (https://music.apple.com/xx/artist/...)');
    }

    // 7) Borító kötelező
    if (coverInput.files.length === 0) {
      isValid = false;
      coverBox.style.borderColor = '#ff3366';
    }

    // Hibaüzenet megjelenítés
    if (!isValid) {
      if (errors.length > 0) {
        errorText.textContent = errors.join(' | ');
      } else {
        errorText.textContent = 'Töltsd ki az összes *-os mezőt!';
      }
    }

    return isValid;
  }
});

// onclick fallback (HTML-ből hívva)
function handleTrackClick() {
  // a DOMContentLoaded listener kezeli – ez csak fallback
  return false;
}

function goBack() {
  window.history.back();
}
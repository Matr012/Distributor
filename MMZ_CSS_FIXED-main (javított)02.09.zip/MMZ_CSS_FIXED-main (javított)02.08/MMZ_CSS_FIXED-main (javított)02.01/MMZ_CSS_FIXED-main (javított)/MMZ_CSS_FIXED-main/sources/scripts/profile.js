// profile.js – teljes, működő verzió (kép csere + modalos visszajelzés)

const DEFAULT_AVATAR = "https://www.shutterstock.com/image-illustration/neon-glowing-user-icon-profile-260nw-2462175375.jpg";

// Profil adatok betöltése
function loadProfile() {
  const userJSON = localStorage.getItem('loggedInUser');
  if (!userJSON) {
    window.location.href = 'login.html';
    return;
  }

  let user;
  try {
    user = JSON.parse(userJSON);
  } catch (err) {
    console.error("Hibás localStorage adat, törlés");
    localStorage.removeItem('loggedInUser');
    window.location.href = 'login.html';
    return;
  }

  const fullName = `${user.firstName || ''} ${user.lastName || ''}`.trim() || user.email || 'Ismeretlen felhasználó';
  const shortName = fullName.length > 18 ? fullName.split(' ')[0] : fullName;

  // Profil oldal elemek frissítése
  const fullNameEl = document.getElementById('fullName');
  if (fullNameEl) fullNameEl.textContent = fullName;

  const emailEl = document.getElementById('emailDisplay');
  if (emailEl) emailEl.textContent = user.email || '-';

  const phoneEl = document.getElementById('phoneDisplay');
  if (phoneEl) phoneEl.textContent = user.phone || '-';

  const nameDisplayEl = document.getElementById('userNameDisplay');
  if (nameDisplayEl) nameDisplayEl.textContent = shortName;

  const profilePic = user.profilePic || DEFAULT_AVATAR;
  const avatarEl = document.getElementById('profileAvatar');
  if (avatarEl) avatarEl.src = profilePic;

  const headerAvatarEl = document.getElementById('headerProfileImg');
  if (headerAvatarEl) headerAvatarEl.src = profilePic;
}

// Auth menü és footer linkek frissítése
function updateAuthenticatedMenu() {
  const userJSON = localStorage.getItem('loggedInUser');
  const authMenu = document.getElementById('authenticatedMenuItems');
  const dropdownLink = document.getElementById('dropdownUploadLink');

  if (authMenu) authMenu.style.display = userJSON ? 'block' : 'none';
  if (dropdownLink) dropdownLink.style.display = userJSON ? 'block' : 'none';
}

// Modal megjelenítése (közös stílusú)
function showModal(title, message, isSuccess = true, callback = null) {
  const modal = document.getElementById('authModal');
  if (!modal) {
    console.error("authModal HTML hiányzik!");
    alert(message);
    return;
  }

  document.getElementById('modalTitle').textContent = title;
  document.getElementById('modalMessage').textContent = message;
  document.getElementById('modalTitle').style.color = isSuccess ? '#4ade80' : '#f87171';

  modal.style.display = 'flex';

  const closeModal = () => {
    modal.style.display = 'none';
    if (typeof callback === 'function') callback();
  };

  document.getElementById('modalOkBtn').onclick = closeModal;
  document.getElementById('modalClose').onclick = closeModal;

  modal.onclick = (e) => {
    if (e.target === modal) closeModal();
  };
}

// Profilkép csere + modal visszajelzés
document.addEventListener('DOMContentLoaded', () => {
  const profilePicInput = document.getElementById('profilePicInput');
  if (profilePicInput) {
    profilePicInput.addEventListener('change', function(e) {
      const file = e.target.files[0];
      if (!file) return;

      const reader = new FileReader();
      reader.onload = function(event) {
        const base64 = event.target.result;

        let user = JSON.parse(localStorage.getItem('loggedInUser') || '{}');
        user.profilePic = base64;
        localStorage.setItem('loggedInUser', JSON.stringify(user));

        document.getElementById('profileAvatar').src = base64;
        document.getElementById('headerProfileImg').src = base64;

        showModal('Siker!', 'Profilképed sikeresen frissítve!', true);
      };

      reader.readAsDataURL(file);
    });
  }

  // Kijelentkezés modalal
  const logoutBtn = document.getElementById('logoutBtn');
  if (logoutBtn) {
    logoutBtn.addEventListener('click', () => {
      localStorage.removeItem('loggedInUser');
      showModal('Kijelentkezve', 'Sikeresen kijelentkeztél!', true, () => {
        window.location.href = '../index.html';
      });
    });
  }

  // Dropdown menü toggle
  const profileBtn = document.getElementById('profileBtn');
  const dropdown = document.getElementById('profileDropdown');
  if (profileBtn && dropdown) {
    profileBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      dropdown.classList.toggle('active');
    });

    document.addEventListener('click', () => {
      dropdown.classList.remove('active');
    });
  }
});

// Oldal betöltéskor mindent frissítünk
window.addEventListener('load', () => {
  const userJSON = localStorage.getItem('loggedInUser');
  const authLinks = document.getElementById('auth-links');
  const userProfile = document.getElementById('user-profile');

  if (userJSON) {
    if (authLinks) authLinks.style.display = 'none';
    if (userProfile) userProfile.style.display = 'flex';

    loadProfile();
    updateAuthenticatedMenu();
  } else {
    if (authLinks) authLinks.style.display = 'flex';
    if (userProfile) userProfile.style.display = 'none';
    window.location.href = 'login.html';
  }
});
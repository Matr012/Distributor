// prods.js – teljes, működő verzió modalos visszajelzéssel + cím visszaállítás (2026.02)

console.log("prods.js betöltve! – most már futok");

function updateAuthenticatedMenu() {
  const user = localStorage.getItem('loggedInUser');
  const authMenu = document.getElementById('authenticatedMenuItems');
  if (authMenu) {
    authMenu.style.display = user ? 'block' : 'none';
  }
}

function updateFooterAuthLinks() {
  const isLoggedIn = !!localStorage.getItem('loggedInUser');
  document.querySelectorAll('.auth-only-register, .auth-only-login').forEach(el => {
    el.style.display = isLoggedIn ? 'none' : 'list-item';
  });
  document.querySelectorAll('.auth-only-service').forEach(el => {
    el.style.display = isLoggedIn ? 'list-item' : 'none';
  });
}

document.addEventListener('DOMContentLoaded', () => {
  console.log("DOMContentLoaded fut – modal inicializálás indul");

  const modal = document.getElementById('ticketModal');
  if (!modal) {
    console.error('CRITICAL: ticketModal ID NEM található a HTML-ben!');
    return;
  }
  console.log("Modal megtalálva");

  const form = document.getElementById('ticketForm');
  const subjectInput = document.getElementById('subject');
  const closeBtn = document.getElementById('closeModal');
  const titleEl = modal.querySelector('h2'); // a cím elem

  if (!closeBtn) console.warn("closeModal ID NEM található – az X gomb nem fog működni");
  if (!titleEl) console.warn("h2 cím elem NEM található a modalban");

  // Eredeti cím mentése (csak egyszer)
  if (titleEl && !titleEl.dataset.originalTitle) {
    titleEl.dataset.originalTitle = titleEl.textContent.trim() || 'Közvetlen üzenet';
  }

  // Booking gombok eseménykezelése
  const buttons = document.querySelectorAll('.prod-ticket-btn');
  console.log(`Talált booking gombok száma: ${buttons.length}`);

  buttons.forEach((btn, index) => {
    btn.addEventListener('click', () => {
      console.log(`Booking gomb kattintás #${index + 1}`);

      const card = btn.closest('.prod-card');
      const artistName = card?.querySelector('.prod-name')?.textContent?.trim() || 'Előadó';

      if (subjectInput) {
        subjectInput.value = `Booking - ${artistName}`;
        console.log(`Subject kitöltve: ${subjectInput.value}`);
      }

      // Visszaállítjuk a formot és címet nyitáskor (biztos, ami biztos)
      if (form) form.style.display = 'block';
      if (titleEl && titleEl.dataset.originalTitle) {
        titleEl.textContent = titleEl.dataset.originalTitle;
      }

      modal.classList.add('show');
      document.body.classList.add('no-scroll');
      console.log("Modal megnyitva + no-scroll bekapcsolva");
    });
  });

  // Bezárás X gombbal
  if (closeBtn) {
    closeBtn.addEventListener('click', () => {
      console.log("X gomb kattintás – bezárás");
      closeModal();
    });
  }

  // Bezárás háttér kattintással
  modal.addEventListener('click', (e) => {
    if (e.target === modal) {
      console.log("Háttér kattintás – bezárás");
      closeModal();
    }
  });

  // ESC billentyű
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && modal.classList.contains('show')) {
      console.log("ESC lenyomva – bezárás");
      closeModal();
    }
  });

  // Form submit – MODALOS visszajelzés
  if (form) {
    form.addEventListener('submit', (e) => {
      e.preventDefault();
      console.log("Form elküldve – modalos visszajelzés indul");

      // Mezők begyűjtése
      const name    = document.getElementById('name')?.value?.trim()    || '';
      const email   = document.getElementById('email')?.value?.trim()   || '';
      const subject = document.getElementById('subject')?.value?.trim() || '';
      const message = document.getElementById('message')?.value?.trim() || '';

      // Validáció
      if (!name || !email || !subject || !message) {
        showModalMessage('Hiányzó adatok', 'Kérlek töltsd ki az összes mezőt!', false);
        return;
      }

      if (!email.includes('@') || email.length < 6) {
        showModalMessage('Érvénytelen e-mail', 'Kérlek adj meg érvényes e-mail címet!', false);
        return;
      }

      // Sikeres küldés modalos üzenet
      showModalMessage(
        'Sikeresen elküldve! 🎉',
        'Köszönjük az üzenetet!\n\n' +
        'Előadó: ' + (subject.split(' - ')[1] || 'ismeretlen') + '\n' +
        'Hamarosan felvesszük veled a kapcsolatot.',
        true
      );

      // Automatikus bezárás 4 mp után + reset
      setTimeout(() => {
        closeModal();
        form.reset();
      }, 4000);
    });
  }

  // Modal üzenet megjelenítése (siker/hiba) – cím ideiglenes változtatása
  function showModalMessage(title, message, isSuccess = true) {
    const modal = document.getElementById('ticketModal');
    const titleEl = modal.querySelector('h2');
    const content = modal.querySelector('.ticket-modal-content');
    const formEl = modal.querySelector('#ticketForm');

    // Ideiglenes cím
    if (titleEl) titleEl.textContent = title;

    // Üzenet elem létrehozása vagy frissítése
    let msgEl = document.getElementById('modalMessage');
    if (!msgEl) {
      msgEl = document.createElement('p');
      msgEl.id = 'modalMessage';
      msgEl.style.textAlign = 'center';
      msgEl.style.margin = '1.5rem 0';
      msgEl.style.fontSize = '1.1rem';
      msgEl.style.lineHeight = '1.5';
      content.insertBefore(msgEl, formEl || content.lastElementChild);
    }

    msgEl.textContent = message;
    msgEl.style.color = isSuccess ? '#4ade80' : '#f87171';

    // Siker esetén elrejtjük a formot
    if (formEl) {
      formEl.style.display = isSuccess ? 'none' : 'block';
    }
  }

  // Bezáró függvény – visszaállítja a címet és formot
  function closeModal() {
    const modal = document.getElementById('ticketModal');
    const titleEl = modal.querySelector('h2');
    const formEl = modal.querySelector('#ticketForm');
    const msgEl = document.getElementById('modalMessage');

    modal.classList.remove('show');
    document.body.classList.remove('no-scroll');
    console.log("Modal bezárva + no-scroll kikapcsolva");

    // Visszaállítjuk az eredeti címet
    if (titleEl && titleEl.dataset.originalTitle) {
      titleEl.textContent = titleEl.dataset.originalTitle;
    } else if (titleEl) {
      titleEl.textContent = 'Közvetlen üzenet'; // fallback
    }

    // Visszaállítjuk a formot és töröljük az üzenetet
    if (formEl) formEl.style.display = 'block';
    if (msgEl) msgEl.remove();
  }
});

window.addEventListener('load', () => {
  console.log("window.load – menük frissítése");
  updateAuthenticatedMenu();
  updateFooterAuthLinks();
});
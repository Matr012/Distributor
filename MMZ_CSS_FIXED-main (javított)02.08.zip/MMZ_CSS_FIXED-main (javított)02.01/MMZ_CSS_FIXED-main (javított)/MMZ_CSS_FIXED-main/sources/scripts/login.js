// login.js

// FAQ accordion (mert a HTML-ből kivettük az inline-t)
document.querySelectorAll('.faq-question').forEach(question => {
  question.addEventListener('click', () => {
    const faqItem = question.parentElement;
    faqItem.classList.toggle('active');
    const toggle = question.querySelector('.faq-toggle');
    toggle.textContent = faqItem.classList.contains('active') ? '−' : '+';
  });
});

// Modal függvény (közös a register.js-sel is, ha később külső fájlba teszed, még jobb)
function showModal(cim, uzenet, sikeres = true, callback = null) {
  const modal = document.getElementById('authModal');
  if (!modal) {
    console.error("Modal HTML elem hiányzik!");
    return;
  }

  document.getElementById('modalTitle').textContent = cim;
  document.getElementById('modalMessage').textContent = uzenet;
  document.getElementById('modalTitle').style.color = sikeres ? '#4ade80' : '#f87171';

  modal.style.display = 'flex';

  const bezarEsFolytat = () => {
    modal.style.display = 'none';
    if (typeof callback === 'function') callback();
  };

  document.getElementById('modalOkBtn').onclick  = bezarEsFolytat;
  document.getElementById('modalClose').onclick = bezarEsFolytat;

  modal.onclick = (e) => {
    if (e.target === modal) bezarEsFolytat();
  };
}

// ESC billentyűvel bezárás
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') {
    const modal = document.getElementById('authModal');
    if (modal) modal.style.display = 'none';
  }
});

// Bejelentkezés kezelése – DOM betöltés után
document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('loginForm');
  if (!form) {
    console.error("Nem található #loginForm az oldalon!");
    return;
  }

  form.addEventListener('submit', function(e) {
    e.preventDefault();

    const email    = document.getElementById('email')?.value?.trim()    || '';
    const password = document.getElementById('password')?.value         || '';

    if (!email || !password) {
      showModal('Hiányzó adat', 'Add meg az e-mail címet és a jelszót!', false);
      return;
    }

    const registeredUsers = JSON.parse(localStorage.getItem('registeredUsers') || '[]');
    const foundUser = registeredUsers.find(u => u.email === email && u.password === password);

    if (foundUser) {
      localStorage.setItem('loggedInUser', JSON.stringify(foundUser));

      showModal(
        'Sikeres bejelentkezés! 👋',
        'Üdvözlünk újra!\nMost már be vagy jelentkezve.\n\nÁtirányítunk a kezdőlapra...',
        true,
        () => {
          window.location.href = '../index.html';
        }
      );
    } else {
      showModal(
        'Bejelentkezés sikertelen',
        'Helytelen e-mail vagy jelszó.\nKérlek próbáld újra!',
        false
      );
    }
  });
});
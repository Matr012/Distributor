// contact.js

document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('contactForm');
  
  if (!form) {
    console.warn("Nem található #contactForm az oldalon");
    return;
  }

  form.addEventListener('submit', function(e) {
    e.preventDefault();

    // Mezők begyűjtése (a HTML struktúrád alapján)
    const inputs = form.querySelectorAll('input[required], textarea[required]');
    let isValid = true;
    let errorMessage = '';

    inputs.forEach(input => {
      if (!input.value.trim()) {
        isValid = false;
        errorMessage = 'Kérlek töltsd ki az összes kötelező mezőt!';
      }
    });

    // Extra e-mail ellenőrzés
    const emailInput = form.querySelector('input[type="email"]');
    if (emailInput && emailInput.value.trim()) {
      const email = emailInput.value.trim();
      if (!email.includes('@') || !email.includes('.')) {
        isValid = false;
        errorMessage = 'Érvénytelen e-mail cím formátum!';
      }
    }

    if (!isValid) {
      showModal('Hiba', errorMessage, false);
      return;
    }

    // Spinner megjelenítése
    showLoadingSpinner();

    // Sikeres küldés szimuláció 3-4 másodperc után
    setTimeout(() => {
      hideLoadingSpinner();
      showModal(
        'Köszönjük!',
        'Az üzenetedet megkaptuk!\n\nHamarosan felvesszük veled a kapcsolatot.',
        true,
        () => {
          form.reset();  // űrlap törlése
        }
      );
    }, 3500); // 3.5 másodperc
  });
});

// Loading spinner megjelenítése
function showLoadingSpinner() {
  let spinner = document.getElementById('loadingSpinnerOverlay');
  if (!spinner) {
    spinner = document.createElement('div');
    spinner.id = 'loadingSpinnerOverlay';
    spinner.className = 'loading-spinner-overlay';
    spinner.innerHTML = '<div class="spinner"></div>';
    document.body.appendChild(spinner);
  }
  spinner.classList.add('active');
}

// Loading spinner elrejtése
function hideLoadingSpinner() {
  const spinner = document.getElementById('loadingSpinnerOverlay');
  if (spinner) {
    spinner.classList.remove('active');
  }
}

// Ha a showModal függvény nincs máshol betöltve, akkor tedd ide (másold be):
function showModal(title, message, isSuccess = true, onClose = null) {
  const modal = document.getElementById('authModal');
  if (!modal) {
    console.error('Modal elem nem található! Ellenőrizd, hogy benne van-e a HTML-ben.');
    alert(message); // fallback ha valamiért nincs modal
    return;
  }

  document.getElementById('modalTitle').textContent = title;
  document.getElementById('modalMessage').textContent = message;
  
  // Szín beállítása
  document.getElementById('modalTitle').style.color = isSuccess ? '#4ade80' : '#f87171';

  modal.style.display = 'flex';

  const closeModal = () => {
    modal.style.display = 'none';
    if (typeof onClose === 'function') onClose();
  };

  document.getElementById('modalOkBtn').onclick = closeModal;
  document.getElementById('modalClose').onclick = closeModal;

  modal.addEventListener('click', function handler(e) {
    if (e.target === modal) {
      closeModal();
      modal.removeEventListener('click', handler);
    }
  });
}

// ESC billentyűvel is bezárható (opcionális)
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') {
    const modal = document.getElementById('authModal');
    if (modal && modal.style.display === 'flex') {
      modal.style.display = 'none';
    }
  }
});
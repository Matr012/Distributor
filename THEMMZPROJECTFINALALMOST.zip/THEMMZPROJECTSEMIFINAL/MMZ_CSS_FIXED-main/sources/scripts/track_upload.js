// ──────────────── MODAL KEZELÉS ────────────────
function showModal(cim, uzenet, sikeres = true, callback = null) {
  const modal = document.getElementById('authModal');
  const titleElem = document.getElementById('modalTitle');
  const msgElem   = document.getElementById('modalMessage');
  const okGomb    = document.getElementById('modalOkBtn');
  const bezarGomb = document.getElementById('modalClose');

  if (!modal) {
    console.error("authModal HTML hiányzik!");
    alert(uzenet);
    if (callback) callback();
    return;
  }

  titleElem.textContent = cim;
  msgElem.textContent   = uzenet;

  // Szín a címhez (zöld / piros)
  titleElem.style.color = sikeres ? '#4ade80' : '#f87171';

  modal.style.display = 'flex';

  const bezar = () => {
    modal.style.display = 'none';
    if (callback) callback();
  };

  okGomb.onclick   = bezar;
  bezarGomb.onclick = bezar;

  modal.onclick = (e) => {
    if (e.target === modal) bezar();
  };
}

// ESC billentyűvel is bezárható
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') {
    const modal = document.getElementById('authModal');
    if (modal) modal.style.display = 'none';
  }
});

const audioInput = document.getElementById("audioInput");
const audioBox = document.getElementById("audioBox");
const audioError = document.getElementById("audioError");
const audioFileName = document.getElementById("audioFileName");
const formError = document.getElementById("formError");
const trackNumberSelect = document.getElementById("trackNumber");

// Audio feltöltés kezelése
audioBox.addEventListener("click", () => {
    audioInput.click();
});

audioInput.addEventListener("change", () => {
    audioError.textContent = "";
    audioFileName.textContent = "";

    const file = audioInput.files[0];
    if (!file) return;

    const allowedTypes = ["audio/mpeg", "audio/wav"];

    if (!allowedTypes.includes(file.type)) {
        audioError.textContent = "Hibás fájlformátum! Csak MP3 vagy WAV engedélyezett.";
        audioInput.value = "";
        return;
    }

    audioFileName.textContent = `✔ Feltöltve: ${file.name}`;
});

// Dátum validáció
const originalDate = document.getElementById("originalReleaseDate");
if (originalDate) {
    originalDate.addEventListener("change", (e) => {
        const value = e.target.value;
        if (value) {
            const datePattern = /^(\d{4})-(\d{2})-(\d{2})$/;
            const match = value.match(datePattern);
            
            if (!match) {
                e.target.value = '';
                return;
            }
            
            const year = parseInt(match[1]);
            
            if (year < 1900 || year > 2099) {
                e.target.value = '';
                formError.textContent = 'Az év 1900 és 2099 között kell legyen!';
                setTimeout(() => formError.textContent = '', 3000);
            }
        }
    });
}

// Automatikus track szám beállítás betöltéskor
window.addEventListener('load', () => {
    const lastTrackNumber = parseInt(localStorage.getItem('lastTrackNumber') || '0');
    if (lastTrackNumber > 0 && lastTrackNumber < 20) {
        trackNumberSelect.value = lastTrackNumber + 1;
    }
});

// Form validáció
function validateForm() {
    let isValid = true;
    formError.textContent = '';
    
    // Stílusok visszaállítása
    document.querySelectorAll('input, select, textarea').forEach(el => {
        el.style.borderColor = '';
    });
    audioBox.style.borderColor = '';
    
    // Kötelező mezők ellenőrzése
    const trackTitle = document.getElementById('trackTitle');
    const isrcRequest = document.getElementById('isrcRequest');
    const genre = document.getElementById('genre');
    const explicitLyrics = document.getElementById('explicitLyrics');
    const composers = document.getElementById('composers');
    
    if (!trackTitle.value.trim()) {
        isValid = false;
        trackTitle.style.borderColor = '#ff3366';
    }
    
    if (!isrcRequest.value) {
        isValid = false;
        isrcRequest.style.borderColor = '#ff3366';
    }
    
    if (!genre.value) {
        isValid = false;
        genre.style.borderColor = '#ff3366';
    }
    
    if (!explicitLyrics.value) {
        isValid = false;
        explicitLyrics.style.borderColor = '#ff3366';
    }
    
    if (!composers.value.trim()) {
        isValid = false;
        composers.style.borderColor = '#ff3366';
    }
    
    // Audio fájl kötelező
    if (!audioInput.files || audioInput.files.length === 0) {
        isValid = false;
        audioBox.style.borderColor = '#ff3366';
    }
    
    if (!isValid) {
        formError.textContent = 'Töltsd ki az összes *-os mezőt és töltsd fel az audio fájlt!';
    }
    
    return isValid;
}

// Track mentése
function saveTrack() {
    if (!validateForm()) {
        return false;
    }
    
    const trackData = {
        trackNumber: trackNumberSelect.value,
        title: document.getElementById('trackTitle').value.trim(),
        subtitle: document.getElementById('trackSubtitle')?.value.trim() || '',
        isrcRequest: document.getElementById('isrcRequest').value,
        originalReleaseDate: document.getElementById('originalReleaseDate')?.value || '',
        genre: document.getElementById('genre').value,
        explicitLyrics: document.getElementById('explicitLyrics').value,
        composers: document.getElementById('composers').value.trim(),
        lyricists: document.getElementById('lyricists')?.value.trim() || '',
        contributors: document.getElementById('contributors')?.value.trim() || '',
        audioFileName: audioInput.files[0]?.name || ''
    };
    
    // Track-ek tárolása localStorage-ban
    let tracks = JSON.parse(localStorage.getItem('tempAlbumTracks') || '[]');
    tracks.push(trackData);
    localStorage.setItem('tempAlbumTracks', JSON.stringify(tracks));
    
    // Utolsó track szám mentése
    localStorage.setItem('lastTrackNumber', trackData.trackNumber);
    
    return true;
}

// MENTÉS gomb - Album véglegesítése
document.getElementById('saveBtn').addEventListener('click', () => {
    // Először mentjük az aktuális track-et
    if (!saveTrack()) {
        return;
    }
    
    // Ellenőrizzük, hogy van-e legalább 1 track
    const tracks = JSON.parse(localStorage.getItem('tempAlbumTracks') || '[]');
    if (tracks.length === 0) {
        formError.textContent = 'Legalább 1 track-et fel kell tölteni!';
        return;
    }
    
    // Album véglegesítése
    const loggedInUser = JSON.parse(localStorage.getItem("loggedInUser"));
    const uploaderEmail = loggedInUser?.email || "anonymous";

    const artist = (localStorage.getItem("tempAlbumArtist") || "").trim() || "Ismeretlen előadó";
    const title = (localStorage.getItem("tempAlbumTitle") || "").trim() || "Ismeretlen album";
    const cover = localStorage.getItem("tempAlbumCover");

    const newAlbum = {
        artist: artist,
        title: title,
        cover: cover,
        uploaderEmail: uploaderEmail,
        tracks: tracks,
        uploadDate: new Date().toISOString()
    };

    let albums = JSON.parse(localStorage.getItem("albums") || "[]");
    albums.push(newAlbum);
    localStorage.setItem("albums", JSON.stringify(albums));

    // Tisztítás
    localStorage.removeItem("tempAlbumArtist");
    localStorage.removeItem("tempAlbumTitle");
    localStorage.removeItem("tempAlbumCover");
    localStorage.removeItem("tempAlbumTracks");
    localStorage.removeItem("lastTrackNumber");

    showModal('Sikerült!', `Album sikeresen mentve ${tracks.length} track-kel!`, true, () => {
        window.location.href = "albums_list.html";
    });
});

// MENTÉS + ÚJ TRACK gomb
document.getElementById('saveAndNewBtn').addEventListener('click', () => {
    if (!saveTrack()) {
        return;
    }
    
    const tracks = JSON.parse(localStorage.getItem('tempAlbumTracks') || '[]');
    showModal('Track mentve!', `Összesen ${tracks.length} track feltöltve.`, true, () => {
        // Oldal újratöltése - az automatikus szám növelés a load eventben van
        location.reload();
    });
});

// Vissza gomb
function goBack() {
    // Ha vannak track-ek, megerősítés kérése
    const tracks = JSON.parse(localStorage.getItem('tempAlbumTracks') || '[]');
    if (tracks.length > 0) {
        showModal('Figyelmeztetés', 'Biztosan vissza akarsz menni? A feltöltött track-ek elvesznek, ha nem mented el az albumot!', false, () => {
            // Ha OK-t nyom, akkor visszalép
            window.history.back();
        });
    } else {
        window.history.back();
    }
}
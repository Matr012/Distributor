console.log("album_upload.js BETÖLTÖDÖTT! – most már futok");

// URL regex minták – csak Spotify/Apple Music előadói profil linkek elfogadása
const spotifyRegex = /^https:\/\/open\.spotify\.com\/artist\/[a-zA-Z0-9]+(\?.*)?$/;
const appleRegex  = /^https:\/\/music\.apple\.com\/[a-z]{2}\/artist\/.+\/[0-9]+(\?.*)?$/;

// ──────────────── MODAL KEZELÉS ────────────────
function showModal(cim, uzenet, sikeres = true, callback = null) {
  const modal = document.getElementById('authModal');
  const titleElem = document.getElementById('modalTitle');
  const msgElem   = document.getElementById('modalMessage');
  const okGomb    = document.getElementById('modalOkBtn');
  const bezarGomb = document.getElementById('modalClose');

  if (!modal) {
    console.error("authModal HTML hiányzik!");
    alert(uzenet);
    if (callback) callback();
    return;
  }

  titleElem.textContent = cim;
  msgElem.textContent   = uzenet;

  // Szín a címhez (zöld / piros)
  titleElem.style.color = sikeres ? '#4ade80' : '#f87171';

  modal.style.display = 'flex';

  const bezar = () => {
    modal.style.display = 'none';
    if (callback) callback();   // ha van callback, lefuttatjuk (pl. átirányítás)
  };

  okGomb.onclick   = bezar;
  bezarGomb.onclick = bezar;

  // Háttérre kattintva is bezárható
  modal.onclick = (e) => {
    if (e.target === modal) bezar();
  };
}

// ESC billentyűvel is bezárható
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') {
    const modal = document.getElementById('authModal');
    if (modal) modal.style.display = 'none';
  }
});

document.addEventListener('DOMContentLoaded', () => {
  console.log("DOMContentLoaded fut – gombok bekötése indul");

  const coverBox    = document.getElementById("coverBox");
  const coverInput  = document.getElementById("coverInput");
  const errorText   = document.getElementById("errorText");
  const previewImage = document.getElementById("previewImage");
  const artistInput = document.getElementById("artistInput");
  const titleInput  = document.getElementById("titleInput");

  // --- Borító feltöltés ---
  coverBox.addEventListener("click", () => {
    coverInput.click();
  });

  coverInput.addEventListener("change", (e) => {
    const file = coverInput.files[0];
    
    // Azonnal töröljük minden előző állapotot
    errorText.textContent = "";
    previewImage.style.display = "none";
    previewImage.src = "";
    localStorage.removeItem("tempAlbumCover");

    // Ha nincs fájl, töröljük az inputot és vége
    if (!file) {
      coverInput.value = "";
      return;
    }

    // Ellenőrizzük, hogy kép-e
    if (!file.type.startsWith("image/")) {
      errorText.textContent = "Csak képfájl tölthető fel!";
      coverInput.value = "";
      return;
    }

    // Beolvassuk a fájlt
    const reader = new FileReader();
    reader.onload = function(event) {
      const img = new Image();
      
      img.onload = function() {
        // KRITIKUS: Ellenőrizzük a méretet - PONTOSAN 1500x1500 kell
        if (img.width !== 1500 || img.height !== 1500) {
          // NEM MEGFELELŐ MÉRET - mindent törlünk
          errorText.textContent = `A borító PONTOSAN 1500x1500 pixel kell legyen! (Feltöltött kép: ${img.width}x${img.height} pixel)`;
          coverInput.value = "";
          previewImage.style.display = "none";
          previewImage.src = "";
          localStorage.removeItem("tempAlbumCover");
          return; // FONTOS: Itt megállunk, NEM folytatjuk
        }
        
        // CSAK IDE JUTUNK, HA A MÉRET PONTOSAN 1500x1500
        previewImage.src = event.target.result;
        previewImage.style.display = "block";
        localStorage.setItem("tempAlbumCover", event.target.result);
      };
      
      img.onerror = function() {
        errorText.textContent = "Hiba történt a kép betöltése során!";
        coverInput.value = "";
        previewImage.style.display = "none";
        previewImage.src = "";
      };
      
      // Betöltjük a képet
      img.src = event.target.result;
    };
    
    reader.onerror = function() {
      errorText.textContent = "Hiba történt a fájl olvasása során!";
      coverInput.value = "";
    };
    
    reader.readAsDataURL(file);
  });

  // --- Átmeneti mentés ---
  if (artistInput) {
    artistInput.addEventListener("input", e => {
      localStorage.setItem("tempAlbumArtist", e.target.value);
    });
  }
  if (titleInput) {
    titleInput.addEventListener("input", e => {
      localStorage.setItem("tempAlbumTitle", e.target.value);
    });
  }

  // --- Dátum mezők validációja ---
  const originalDate = document.getElementById("originalReleaseDate");
  const digitalDate = document.getElementById("digitalReleaseDate");
  
  if (originalDate) {
    // Amikor a mező elveszti a fókuszt, ellenőrizzük a dátum formátumot
    originalDate.addEventListener("change", (e) => {
      const value = e.target.value;
      if (value) {
        // Ellenőrzi, hogy az év 4 számjegyű-e (YYYY-MM-DD formátum)
        const datePattern = /^(\d{4})-(\d{2})-(\d{2})$/;
        const match = value.match(datePattern);
        
        if (!match) {
          e.target.value = '';
          return;
        }
        
        const year = parseInt(match[1]);
        const month = parseInt(match[2]);
        const day = parseInt(match[3]);
        
        // Év ellenőrzés: 1900-2099
        if (year < 1900 || year > 2099) {
          e.target.value = '';
          errorText.textContent = 'Az év 1900 és 2099 között kell legyen!';
          setTimeout(() => errorText.textContent = '', 3000);
        }
      }
    });
  }
  
  if (digitalDate) {
    // Amikor a mező elveszti a fókuszt, ellenőrizzük a datetime formátumot
    digitalDate.addEventListener("change", (e) => {
      const value = e.target.value;
      if (value) {
        // Ellenőrzi, hogy az év 4 számjegyű-e (YYYY-MM-DDTHH:mm formátum)
        const datetimePattern = /^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2})$/;
        const match = value.match(datetimePattern);
        
        if (!match) {
          e.target.value = '';
          return;
        }
        
        const year = parseInt(match[1]);
        
        // Év ellenőrzés: 2000-2099
        if (year < 2000 || year > 2099) {
          e.target.value = '';
          errorText.textContent = 'Az év 2000 és 2099 között kell legyen!';
          setTimeout(() => errorText.textContent = '', 3000);
        }
      }
    });
  }

  // --- TRACK gomb ---
  const trackBtn = document.getElementById("trackUploadBtn");
  if (trackBtn) {
    trackBtn.addEventListener('click', (e) => {
      e.preventDefault();
      console.log("TRACK gomb kattintás – validáció indul");

      const isValid = validateForm();
      if (isValid) {
        console.log("Minden OK – átirányítás track_upload.html-re");
        errorText.textContent = '';
        window.location.href = 'track_upload.html';
      } else {
        console.log("Hiba – nem megy át");
      }
    });
  }

  // --- Validáció ---
  function validateForm() {
    let isValid = true;
    let errors = [];
    errorText.textContent = '';

    // Stílusok visszaállítása
    document.querySelectorAll('input, select').forEach(el => el.style.borderColor = '');
    coverBox.style.borderColor = '';

    // 1) Albumkód igénylés – kötelező választás
    const albumCodeSelect = document.getElementById("albumCodeRequest");
    if (!albumCodeSelect.value) {
      isValid = false;
      albumCodeSelect.style.borderColor = '#ff3366';
    }

    // 2) EAN/UPC – csak akkor kötelező, ha albumkód igénylés NEM "igen"
    const eanInput = document.getElementById("eanInput");
    if (albumCodeSelect.value !== 'igen' && eanInput.value.trim() === '') {
      isValid = false;
      eanInput.style.borderColor = '#ff3366';
    }

    // 3) Kötelező szöveges mezők
    const requiredTextIds = ['artistInput', 'titleInput'];
    requiredTextIds.forEach(id => {
      const field = document.getElementById(id);
      if (!field) return;
      if (field.value.trim() === '') {
        isValid = false;
        field.style.borderColor = '#ff3366';
      }
    });

    // 4) Kötelező legördülő menük (Stílus, Továbbterjesztés)
    const requiredSelectIds = ['genreSelect', 'distributionSelect'];
    requiredSelectIds.forEach(id => {
      const field = document.getElementById(id);
      if (!field) return;
      if (!field.value) {
        isValid = false;
        field.style.borderColor = '#ff3366';
      }
    });

    // 5) Spotify URL – kötelező + csak Spotify előadói profil link
    const spotifyUrlField = document.getElementById('spotifyUrl');
    if (!spotifyUrlField.value.trim()) {
      isValid = false;
      spotifyUrlField.style.borderColor = '#ff3366';
    } else if (!spotifyRegex.test(spotifyUrlField.value.trim())) {
      isValid = false;
      spotifyUrlField.style.borderColor = '#ff3366';
      errors.push('Spotify URL: csak előadói profil link elfogadott (https://open.spotify.com/artist/...)');
    }

    // 6) Apple Music URL – kötelező + csak Apple Music előadói profil link
    const appleUrlField = document.getElementById('appleMusicUrl');
    if (!appleUrlField.value.trim()) {
      isValid = false;
      appleUrlField.style.borderColor = '#ff3366';
    } else if (!appleRegex.test(appleUrlField.value.trim())) {
      isValid = false;
      appleUrlField.style.borderColor = '#ff3366';
      errors.push('Apple Music URL: csak előadói profil link elfogadott (https://music.apple.com/xx/artist/...)');
    }

    // 7) Borító kötelező
    if (coverInput.files.length === 0) {
      isValid = false;
      coverBox.style.borderColor = '#ff3366';
    }

    // Hibaüzenet megjelenítés
    if (!isValid) {
      if (errors.length > 0) {
        errorText.textContent = errors.join(' | ');
      } else {
        errorText.textContent = 'Töltsd ki az összes *-os mezőt!';
      }
    }

    return isValid;
  }
});

// onclick fallback (HTML-ből hívva)
function handleTrackClick() {
  // a DOMContentLoaded listener kezeli – ez csak fallback
  return false;
}

function goBack() {
  window.history.back();
}
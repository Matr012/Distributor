document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('registerForm');

  form.addEventListener('submit', (e) => {
    e.preventDefault();

    const username = document.getElementById('username').value;
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;

    let users = JSON.parse(localStorage.getItem('users')) || [];

    const userExists = users.some(user => user.username === username || user.email === email);
    if (userExists) {
      showModal('Hiba', 'Felhasználónév vagy e-mail már létezik!', false);
      return;
    }

    users.push({ username, email, password });
    localStorage.setItem('users', JSON.stringify(users));

    showModal('Sikeres regisztráció!', 'Átirányítás a bejelentkezéshez...', true, () => {
      window.location.href = 'login.html';
    });
  });
});

// ──────────────── MODAL KEZELÉS ────────────────

function showModal(cim, uzenet, sikeres = true, callback = null) {
  const modal = document.getElementById('authModal');
  const titleElem = document.getElementById('modalTitle');
  const msgElem   = document.getElementById('modalMessage');
  const okGomb    = document.getElementById('modalOkBtn');
  const bezarGomb = document.getElementById('modalClose');

  titleElem.textContent = cim;
  msgElem.textContent   = uzenet;

  // Szín a címhez (zöld / piros)
  titleElem.style.color = sikeres ? '#4ade80' : '#f87171';

  modal.style.display = 'flex';

  const bezar = () => {
    modal.style.display = 'none';
    if (callback) callback();   // ha van callback, lefuttatjuk (pl. átirányítás)
  };

  okGomb.onclick   = bezar;
  bezarGomb.onclick = bezar;

  // Háttérre kattintva is bezárható
  modal.onclick = (e) => {
    if (e.target === modal) bezar();
  };
}

// ESC billentyűvel is bezárható
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') {
    document.getElementById('authModal').style.display = 'none';
  }
});